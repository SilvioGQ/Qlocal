import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function Header() {
  return (
    <View style={styles.container}>
    <Text style={styles.qlocal}> Qlocal
    </Text>
    <Image style={styles.logo} source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Hamburger_icon.svg/1200px-Hamburger_icon.svg.png'}} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:0.2,
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    padding: 17,
    flexDirection:"row",
    backgroundColor: "#228B22",
shadowColor: "#000",
shadowOffset: {
	width: 0,
	height: 8,
},
shadowOpacity: 0.46,
shadowRadius: 11.14,
elevation:12,
borderRadius: 7,
  },
  logo: {
    width: 30,
    height: 30
  },
  qlocal: {
    fontSize: 24,
    fontWeight: "bold"
  }
});