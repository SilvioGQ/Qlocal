import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, ScrollView, SectionList } from 'react-native';
import Lista from './item/Lista';
export default class Listaunidade extends Component {
  state = {
lists: [
  {
    id: 1,
    Image: 'https://pepfurg.files.wordpress.com/2012/09/foto-23.jpg?w=800',
    title: 'Praça tramandaré',
    description: 'Parque',
    distance: '500m de distancia'
  },
  {
    id: 2,
    Image: 'https://pepfurg.files.wordpress.com/2012/09/foto-23.jpg?w=800',
    title: 'Praça tramandaré 2',
    description: 'Parque',
    distance: '500m de distancia'
  },
]
};

render() {
  return(
    <View style={styles.container}> 
    { this.state.lists.map(lists => 
    <Lista key= {Lista.id} lista={lista}/>
    )} 
    </View>
  )
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});
