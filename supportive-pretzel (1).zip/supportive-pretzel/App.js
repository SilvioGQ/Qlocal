import React,  { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
// You can import from local files
import Header from './components/Header';
import Toolbar from './components/toolbar';
import Item from './components/Itens/item/item'
import Lista from './components/ListaFake'
// or any pure javascript modules available in npm

export default function App() {
  return (
    <View style={styles.container}>
    <Header/>
    <Toolbar/>
    <Lista/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});
