import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, ScrollView, SectionList } from 'react-native';
import Item from './item';
export default class Listas extends Component {
  state = {
 itens: [
  {
    id: 1,
    image: 'https://pepfurg.files.wordpress.com/2012/09/foto-23.jpg?w=800',
    title: 'Praça tramandaré',
    description: 'Parque',
    distance: '500m de distancia'
  },
  {
    id: 2,
    image: 'https://pepfurg.files.wordpress.com/2012/09/foto-23.jpg?w=800',
    title: 'Praça tramandaré 2',
    description: 'Parque',
    distance: '500m de distancia'
  },
]
};

render() {
  return(
    <View style={styles.container}> 
    { this.state.itens.map(item => 
    <Item key= {item.id} item={item}/>
    )} 
    </View>
  )
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});