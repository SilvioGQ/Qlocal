import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, ScrollView, SectionList } from 'react-native';
import Listas from './Lista'
const Item = ({ item: { image, title, description, distance}}) => (
  <View style={styles.container}>
  <Image source= {{ uri:image}} style= {styles.image} />
  <Text style= {styles.title}>{title}</Text>
    <Text style= {styles.description}>{description}</Text>
      <Text style= {styles.distance}>{distance}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});

export default Item 