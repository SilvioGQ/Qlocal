import * as React from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity, TextInput } from 'react-native';
const Tela = Dimensions.get('screen').width
export default function Login( {navigation}) {
  const [value, onChangeText] = React.useState('Adicione uma informação');
  return (    
    <View style={styles.telaum}> 
    <View style={styles.qlocal}>
      <Text style={styles.title}>
      Crie seu cadastro!
      </Text>
      <View style={styles.label}>
      <Text style={styles.paragraph}>
      Nome
      </Text>
      <TextInput
      style= {styles.input}
      onChangeText={text => onChangeText(text)}
      value={value.name}
      placeholder='Digite seu nome'
    />
      </View>
      <View style={styles.label}>
      <Text style={styles.paragraph}>
      Email
      </Text>
      <TextInput
      style= {styles.input}
      onChangeText={text => onChangeText(text)}
      value={value.name}
      placeholder='Digite seu nome'
    />
      </View>
      <View style={styles.label}>
      <Text style={styles.paragraph}>
      Senha
      </Text>
      <TextInput
      style= {styles.input}
      onChangeText={text => onChangeText(text)}
      value={value.name}
      placeholder='Digite seu nome'
    />
      </View>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Header")}> 
      <Text style={styles.outrotexto}>Continuar</Text>
      </TouchableOpacity>
      </View>
      </View>
  );
}

const styles = StyleSheet.create({
    telaum:{
    flexGrow: 1,
    backgroundColor: '#228B22',
    alignItems:"center",
    alignContent:"center",
    width: Tela
  },
  qlocal:{
    flex:1,
    justifyContent:"space-around",
    paddingTop:35
  },
    title: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    color: "#ffffff"
  },
  paragraph: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: "#ffffff"
  },
  outrotexto: {
    fontSize:18,
    fontWeight: "bold",
    color:"#ffffff",
    textAlign: 'center',
  },
label:{
  alignItems: 'flex-start'
},
input:{
  width: 220,
  height:30,
  backgroundColor:'#000000',
  color: '#ffffff',
  borderRadius:13
},
button:{
    padding:13,
    backgroundColor:"#66BF00",
    color:"#FFFFFF",
    borderRadius:20,
    width: 255,
    alignItems:'center',
    shadowColor: "#000",
    shadowOffset: {
    	width: 0,
    	height: 4,
    },
    shadowOpacity: 0.32,
    shadowRadius: 5.46,
    elevation: 9,
  },
});