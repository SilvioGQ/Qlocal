import React from 'react';
import { Text, View, StyleSheet, Image, StatusBar, TouchableOpacity, Dimensions } from 'react-native';
import Constants from "expo-constants";
const Tela = Dimensions.get('screen').width
export default function Local() {
  return (
    <View style={styles.container}>
    <View  style={styles.row}> 
    <Text style={styles.qlocal}>Qlocal
    </Text>
    <TouchableOpacity>
    <Image style={styles.logo} source={require('../../assets/cardapio.png')}/>
    </TouchableOpacity>
    </View>
    <Image style={styles.imagem} source={{uri: 'https://pepfurg.files.wordpress.com/2012/09/foto-23.jpg?w=800'}}/>
    <Text style= {styles.nome}> Praça Tramandaré </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow : 1,
  },
  row:{
    backgroundColor: "#228B22",
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15,
  },
  logo: {
    width: 28,
    height: 28,
  },
  qlocal: {
    fontSize: 24,
    color: '#fff'
  },
  imagem: {
    width: Tela,
    height:280
  },
  nome:{
    fontSize: 18,
    marginVertical: 20
  }
});