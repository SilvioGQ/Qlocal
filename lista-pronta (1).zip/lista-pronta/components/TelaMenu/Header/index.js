import React from 'react';
import { Text, View, StyleSheet, Image, StatusBar, TouchableOpacity } from 'react-native';
import Constants from "expo-constants";
import Toolbar from '../Toolbar/toolbar'
import Lista from '../Itens/Lista'

export default function Menu() {
  return (
    <View style={styles.container}>
    <View  style={styles.row}> 
    <Text style={styles.qlocal}> Qlocal
    </Text>
    <TouchableOpacity>
    <Image style={styles.logo} source={require('../../../assets/cardapio.png')}/>
    </TouchableOpacity>
    </View>
    <Toolbar/>
    <Lista/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    justifyContent: 'center',
  },
  row:{
    flexGrow : 0.4,
    backgroundColor: "#228B22",
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 15,
  },
  logo: {
    width: 28,
    height: 28,
  },
  qlocal: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold'
  }
});