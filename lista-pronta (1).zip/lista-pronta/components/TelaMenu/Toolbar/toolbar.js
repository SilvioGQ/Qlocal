import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function Toolbar() {
  return (
    <View style={styles.container}>
    <TouchableOpacity style={styles.toot}> 
    <Image style={styles.logo} source={require('./../../../assets/ordenar.png')} />
    <Text style={styles.qlocal}> Ordenar
    </Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.toot}> 
    <Image style={styles.logo} source={require('./../../../assets/filtro.png')} />
    <Text style={styles.qlocal}> Filtrar
    </Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.toot}> 
    <Image style={styles.lupa} source={require('./../../../assets/Group.png')} />
    <Text style={styles.qlocal}> Pesquisar
    </Text>
    </TouchableOpacity>
    </View>
    );
}

const styles = StyleSheet.create({
  container: {
    flexGrow:0.2,
    alignItems: 'center',
    justifyContent: 'space-around',
    padding: 10,
    paddingVertical: 20,
    flexDirection:"row",
    backgroundColor: "#EDEDED",
  },
  toot:{
    flexDirection:'row'
  },
  logo: {
    width: 22,
    height: 22
  },
    lupa: {
    width: 22,
    height: 23
  },
  qlocal: {
    fontSize: 13,
    fontWeight: "Regular"
  }
});