import * as React from 'react';
import { Text, View, StyleSheet, Image, Dimensions, TouchableOpacity } from 'react-native';
const Tela = Dimensions.get('screen').width
export default function Primeira( {navigation}) {
  return (    
    <View style={styles.telaum}> 
    <View style={styles.qlocal}>
      <Text style={styles.paragraph}>
      Qlocal
      </Text>
      </View>
      <View style={styles.baixo}>
      <Text style={styles.subtitulo}>Ainda não tem uma conta conosco? </Text>
      <TouchableOpacity onPress={() => navigation.navigate("Login")}> 
      <Text style={styles.outrotexto}>Clique aqui para se cadastrar</Text>
      </TouchableOpacity>
      </View>

      <View style={styles.segundatela}>
      <Text style={styles.naobranco}>ou então acesse com a sua conta do </Text>
      <View style={styles.button}>
      <TouchableOpacity  onPress= {() => navigation.navigate("Header")}>
      <Text style = {styles.face}>
        Facebook
      </Text>
      </TouchableOpacity >
      <Text style={styles.naobranco}>ou</Text>
      <TouchableOpacity onPress= {() => navigation.navigate("Header")}>
      <Text style = {styles.google}>
        Google
      </Text>
      </TouchableOpacity>
      </View>
      </View>
      </View>
  );
}

const styles = StyleSheet.create({
  segundatela:{
    flex: 0.4,
    backgroundColor: "#ffffff",
    alignItems: "center",
    justifyContent: "space-around",
    width: Tela
  },
  naobranco:{
    fontSize: 18,
    color:"#8B8181",
    paddingVertical:5
  },
  button:{
    flex: 0.85,
    justifyContent: "space-around",
    alignItems:"center",
    textAlign:"center",
    padding:3
  },
  face:{
      padding: 11,
      borderRadius: 16, 
      backgroundColor: '#1976D2',
      color:"#ffffff",
      width: 270,
      fontSize:18,
      textAlign:"center",
  },
    google:{
      padding: 11 ,
      backgroundColor: '#ffffff',
      color:"#000000",
      borderRadius: 16,
      width: 270,
      borderWidth: 1,
      borderColor: "#228B22",
      fontSize:18,
      textAlign:"center",
  },
    telaum:{
    flexGrow: 4,
    backgroundColor: '#228B22',
    justifyContent:"center",
    alignItems:"center",
    alignContent:"center",
    width: Tela
  },
  baixo:{
    justifyContent:"flex-end",
    
  },
  qlocal:{
    flex:1,
    justifyContent:"center",
  },
  paragraph: {
    fontSize: 48,
    fontWeight: 'bold',
    textAlign: 'center',
    color: "#ffffff"
  },
  subtitulo: {
    fontSize: 18,
    color:"#ffffff",
    textAlign: 'center',

  },
  outrotexto: {
    fontSize:18,
    fontWeight: "bold",
    color:"#ffffff",
    textAlign: 'center',
  },
});
