import React from 'react';
import {createStackNavigator} from '@react-navigation/stack'
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
// You can import from local files
import Primeira from './TelaInicial/index'
import Menu from './TelaMenu/Header/index';
import Local from './Local/index'
import Login from './TelaLogin1/index'
const Stack = createStackNavigator();

export default function Routes() {
    return (
        <Stack.Navigator initialRouteName= 'Primeira'>
            <Stack.Screen name="Primeira" component= {Primeira}  options={{
    headerTransparent: true,
    headerTitle: ''
  }}/>
            <Stack.Screen name="Header" component= {Menu} options={{
    headerTransparent: true,
    headerTitle: '' }}/>
                <Stack.Screen name="Local" component= {Local} options={{
    headerTransparent: true,
    headerTitle: '' }}/>
                <Stack.Screen name="Login" component= {Login} options={{
    headerTransparent: true,
    headerTitle: '' }}/>
        </Stack.Navigator>

    )
}