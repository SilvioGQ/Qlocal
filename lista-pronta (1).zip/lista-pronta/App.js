import React from 'react';
import { Text, View, StyleSheet, StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import Constants from 'expo-constants';
// You can import from local files
import Routes from './components/routes';
import Login from './components/TelaLogin1/index'
import Menu from './components/TelaMenu/Header/index';
export default function App() {
  return (
    <View style={styles.container}>
  <StatusBar backgroundColor="#228B22"
  translucent={true}
  barStyle='light-content'/>
  <NavigationContainer> 
  <Routes/>
  </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
  },
});